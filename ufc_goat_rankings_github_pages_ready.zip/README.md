# UFC All-Time Rankings

Static UFC-only GOAT ranking app.

## Live preview setup with GitHub Pages

Recommended repo name: `ufc-goat-rankings`

1. Create a new public GitHub repository.
2. Upload these files to the root of the repository:
   - `index.html`
   - `.nojekyll`
   - `assets/fighters/...`
   - `README.md`
3. In GitHub, open the repo and go to **Settings → Pages**.
4. Under **Build and deployment**, choose:
   - Source: **Deploy from a branch**
   - Branch: **main**
   - Folder: **/root**
5. Save.

Your live site should become:

```txt
https://codyking0602.github.io/ufc-goat-rankings/
```

## Update workflow

For each new version:

1. Replace `index.html` for layout/data updates.
2. Add fighter photos into `assets/fighters/`.
3. Keep photo names consistent:
   - `fighter-name-thumb.webp`
   - `fighter-name.webp`
4. Commit changes to `main`.
5. Refresh the GitHub Pages URL on your phone.

GitHub Pages can take a few minutes to publish updates.

## Current image naming format

```txt
assets/fighters/jon-jones-thumb.webp
assets/fighters/jon-jones.webp
assets/fighters/georges-st-pierre-thumb.webp
assets/fighters/georges-st-pierre.webp
```

Use two images per fighter long-term:

- Ranking card thumbnail: about 160x160 WebP
- Fighter profile image: about 700–900px tall WebP

## App status

Current build includes:

- UFC all-time P4P leaderboard
- Fighter profile drawer
- Compare mode
- Division views
- Scoring notes
- Mobile layout polish
- Real fighter image assets for current uploaded batch
